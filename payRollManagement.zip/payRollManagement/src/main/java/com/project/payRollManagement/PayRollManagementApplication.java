package com.project.payRollManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayRollManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayRollManagementApplication.class, args);
	}

}
